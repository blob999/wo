#include <stdio.h>
#include <stdlib.h>

#define MAX_VERTICES 100

// Structure for representing a node in the adjacency list
typedef struct AdjListNode {
    int dest;
    struct AdjListNode* next;
} AdjListNode;

// Structure for representing adjacency list
typedef struct {
    AdjListNode* head;
} AdjList;

// Structure for representing the graph
typedef struct {
    int numVertices;
    AdjList* array;
} Graph;

// Function to create a new adjacency list node
AdjListNode* newAdjListNode(int dest) {
    AdjListNode* newNode = (AdjListNode*)malloc(sizeof(AdjListNode));
    newNode->dest = dest;
    newNode->next = NULL;
    return newNode;
}

// Function to create a graph with given number of vertices
Graph* createGraph(int numVertices) {
    Graph* graph = (Graph*)malloc(sizeof(Graph));
    graph->numVertices = numVertices;

    // Create an array of adjacency lists. Size of the array will be numVertices.
    graph->array = (AdjList*)malloc(numVertices * sizeof(AdjList));

    // Initialize each adjacency list as empty by making head as NULL
    for (int i = 0; i < numVertices; ++i)
        graph->array[i].head = NULL;

    return graph;
}

// Function to add an edge to an undirected graph
void addEdge(Graph* graph, int src, int dest) {
    // Add an edge from src to dest. A new node is added to the adjacency list of src.
    AdjListNode* newNode = newAdjListNode(dest);
    newNode->next = graph->array[src].head;
    graph->array[src].head = newNode;

    // Since graph is undirected, add an edge from dest to src also
    newNode = newAdjListNode(src);
    newNode->next = graph->array[dest].head;
    graph->array[dest].head = newNode;
}

// Function to print the adjacency lists
void printAdjLists(Graph* graph) {
    printf("Adjacency Lists:\n");
    for (int v = 0; v < graph->numVertices; ++v) {
        printf("Vertex %d: ", v);
        AdjListNode* temp = graph->array[v].head;
        while (temp) {
            printf("%d ", temp->dest);
            temp = temp->next;
        }
        printf("\n");
    }
}

// Function to perform Depth First Search (DFS) traversal
void DFSUtil(Graph* graph, int vertex, int visited[]) {
    // Mark the current node as visited and print it
    visited[vertex] = 1;
    printf("%d ", vertex);

    // Recur for all the vertices adjacent to this vertex
    AdjListNode* adjNode = graph->array[vertex].head;
    while (adjNode) {
        int adjVertex = adjNode->dest;
        if (!visited[adjVertex]) {
            DFSUtil(graph, adjVertex, visited);
        }
        adjNode = adjNode->next;
    }
}

void DFS(Graph* graph, int startVertex) {
    // Create an array to mark visited vertices
    int* visited = (int*)calloc(graph->numVertices, sizeof(int));

    // Call the recursive helper function to perform DFS traversal
    printf("DFS Traversal starting from vertex %d: ", startVertex);
    DFSUtil(graph, startVertex, visited);
    printf("\n");

    // Free dynamically allocated memory
    free(visited);
}

int main() {
    int numVertices, numEdges, from, to;

    // Input the number of vertices and edges
    printf("Enter the number of vertices and edges: ");
    scanf("%d %d", &numVertices, &numEdges);

    // Create a graph with the given number of vertices
    Graph* graph = createGraph(numVertices);

    // Input the edges
    printf("Enter the edges (from to): \n");
    for (int i = 0; i < numEdges; ++i) {
        scanf("%d %d", &from, &to);
        addEdge(graph, from, to);
    }

    // Print the adjacency lists
    printAdjLists(graph);

    // Input the starting vertex for DFS traversal
    int startVertex;
    printf("Enter the starting vertex for DFS traversal: ");
    scanf("%d", &startVertex);

    // Perform DFS traversal starting from the given vertex
    DFS(graph, startVertex);

    // Free dynamically allocated memory
    free(graph->array);
    free(graph);

    return 0;
}
