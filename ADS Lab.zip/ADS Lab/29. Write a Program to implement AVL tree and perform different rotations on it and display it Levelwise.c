#include <stdio.h>
#include <stdlib.h>

// Structure for a node in AVL Tree
typedef struct AVLNode {
    int data;
    struct AVLNode* left;
    struct AVLNode* right;
    int height;
} AVLNode;

// Function to create a new node
AVLNode* createNode(int data) {
    AVLNode* newNode = (AVLNode*)malloc(sizeof(AVLNode));
    if (newNode == NULL) {
        printf("Memory allocation failed\n");
        exit(EXIT_FAILURE);
    }
    newNode->data = data;
    newNode->left = NULL;
    newNode->right = NULL;
    newNode->height = 1;
    return newNode;
}

// Function to get the height of a node
int getHeight(AVLNode* node) {
    if (node == NULL) return 0;
    return node->height;
}

// Function to perform single right rotation
AVLNode* rightRotate(AVLNode* y) {
    AVLNode* x = y->left;
    AVLNode* T2 = x->right;

    // Perform rotation
    x->right = y;
    y->left = T2;

    // Update heights
    y->height = 1 + ((getHeight(y->left) > getHeight(y->right)) ? getHeight(y->left) : getHeight(y->right));
    x->height = 1 + ((getHeight(x->left) > getHeight(x->right)) ? getHeight(x->left) : getHeight(x->right));

    // Return new root
    return x;
}

// Function to perform single left rotation
AVLNode* leftRotate(AVLNode* x) {
    AVLNode* y = x->right;
    AVLNode* T2 = y->left;

    // Perform rotation
    y->left = x;
    x->right = T2;

    // Update heights
    x->height = 1 + ((getHeight(x->left) > getHeight(x->right)) ? getHeight(x->left) : getHeight(x->right));
    y->height = 1 + ((getHeight(y->left) > getHeight(y->right)) ? getHeight(y->left) : getHeight(y->right));

    // Return new root
    return y;
}

// Function to get the balance factor of a node
int getBalance(AVLNode* node) {
    if (node == NULL) return 0;
    return getHeight(node->left) - getHeight(node->right);
}

// Function to insert a node into the AVL Tree
AVLNode* insert(AVLNode* node, int data) {
    // Perform standard BST insertion
    if (node == NULL) return createNode(data);

    if (data < node->data) {
        node->left = insert(node->left, data);
    } else if (data > node->data) {
        node->right = insert(node->right, data);
    } else {
        // Duplicate keys are not allowed
        return node;
    }

    // Update height of this ancestor node
    node->height = 1 + ((getHeight(node->left) > getHeight(node->right)) ? getHeight(node->left) : getHeight(node->right));

    // Get the balance factor of this ancestor node to check whether this node became unbalanced
    int balance = getBalance(node);

    // If this node becomes unbalanced, then there are 4 cases

    // Left Left Case
    if (balance > 1 && data < node->left->data) {
        return rightRotate(node);
    }

    // Right Right Case
    if (balance < -1 && data > node->right->data) {
        return leftRotate(node);
    }

    // Left Right Case
    if (balance > 1 && data > node->left->data) {
        node->left = leftRotate(node->left);
        return rightRotate(node);
    }

    // Right Left Case
    if (balance < -1 && data < node->right->data) {
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }

    // Return the unchanged node pointer
    return node;
}

// Function to print AVL tree in level order
void printLevelOrder(AVLNode* root) {
    if (root == NULL) return;

    // Create an auxiliary queue
    AVLNode* queue[1000];
    int front = 0, rear = 0;

    // Enqueue root
    queue[rear++] = root;

    while (front < rear) {
        AVLNode* tempNode = queue[front++];

        // Print the data of the current node
        printf("%d ", tempNode->data);

        // Enqueue left child
        if (tempNode->left != NULL) {
            queue[rear++] = tempNode->left;
        }

        // Enqueue right child
        if (tempNode->right != NULL) {
            queue[rear++] = tempNode->right;
        }
    }
    printf("\n");
}

int main() {
    AVLNode* root = NULL;
    int numNodes, data;

    // Input the number of nodes
    printf("Enter the number of nodes: ");
    scanf("%d", &numNodes);

    // Input the values of the nodes
    printf("Enter the values of the nodes:\n");
    for (int i = 0; i < numNodes; i++) {
        scanf("%d", &data);
        root = insert(root, data);
    }

    // Print the AVL Tree level-wise
    printf("AVL Tree Level-wise: ");
    printLevelOrder(root);

    return 0;
}
