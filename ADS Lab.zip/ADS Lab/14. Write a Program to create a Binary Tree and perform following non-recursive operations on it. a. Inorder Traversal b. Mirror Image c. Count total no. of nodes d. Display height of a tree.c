#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node* left;
    struct Node* right;
} Node;

typedef struct Stack {
    Node* arr[100];
    int top;
} Stack;

void initStack(Stack* stack) {
    stack->top = -1;
}

int isEmpty(Stack* stack) {
    return stack->top == -1;
}

void push(Stack* stack, Node* node) {
    stack->arr[++stack->top] = node;
}

Node* pop(Stack* stack) {
    return stack->arr[stack->top--];
}

Node* peek(Stack* stack) {
    return stack->arr[stack->top];
}

Node* createNode(int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    return newNode;
}

Node* insert(Node* root, int data) {
    if (root == NULL) {
        return createNode(data);
    }
    Stack stack;
    initStack(&stack);
    push(&stack, root);
    while (!isEmpty(&stack)) {
        Node* current = pop(&stack);
        if (current->left == NULL) {
            current->left = createNode(data);
            break;
        } else {
            push(&stack, current->left);
        }
        if (current->right == NULL) {
            current->right = createNode(data);
            break;
        } else {
            push(&stack, current->right);
        }
    }
    return root;
}

void inorder(Node* root) {
    Stack stack;
    initStack(&stack);
    Node* current = root;
    while (current != NULL || !isEmpty(&stack)) {
        while (current != NULL) {
            push(&stack, current);
            current = current->left;
        }
        current = pop(&stack);
        printf("%d ", current->data);
        current = current->right;
    }
    printf("\n");
}

void mirror(Node* root) {
    if (root == NULL) return;
    Stack stack;
    initStack(&stack);
    push(&stack, root);
    while (!isEmpty(&stack)) {
        Node* current = pop(&stack);
        Node* temp = current->left;
        current->left = current->right;
        current->right = temp;
        if (current->left != NULL) {
            push(&stack, current->left);
        }
        if (current->right != NULL) {
            push(&stack, current->right);
        }
    }
}

int countTotalNodes(Node* root) {
    if (root == NULL) return 0;
    Stack stack;
    initStack(&stack);
    push(&stack, root);
    int count = 0;
    while (!isEmpty(&stack)) {
        Node* current = pop(&stack);
        count++;
        if (current->right != NULL) {
            push(&stack, current->right);
        }
        if (current->left != NULL) {
            push(&stack, current->left);
        }
    }
    return count;
}

int getHeight(Node* root) {
    if (root == NULL) return 0;
    Stack stack;
    initStack(&stack);
    push(&stack, root);
    int height = 0;
    while (1) {
        int nodeCount = stack.top + 1;
        if (nodeCount == 0) return height;
        height++;
        while (nodeCount > 0) {
            Node* node = pop(&stack);
            if (node->left != NULL) push(&stack, node->left);
            if (node->right != NULL) push(&stack, node->right);
            nodeCount--;
        }
    }
}

int main() {
    Node* root = NULL;
    int choice, value;

    while (1) {
        printf("1. Insert\n");
        printf("2. Inorder Traversal\n");
        printf("3. Mirror Image\n");
        printf("4. Count Total Nodes\n");
        printf("5. Display Height\n");
        printf("6. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter value to insert: ");
                scanf("%d", &value);
                root = insert(root, value);
                break;
            case 2:
                printf("Inorder Traversal: ");
                inorder(root);
                break;
            case 3:
                mirror(root);
                printf("Mirror image created.\n");
                break;
            case 4:
                printf("Total Nodes: %d\n", countTotalNodes(root));
                break;
            case 5:
                printf("Height of the Tree: %d\n", getHeight(root));
                break;
            case 6:
                exit(0);
            default:
                printf("Invalid choice\n");
                break;
        }
    }

    return 0;
}
