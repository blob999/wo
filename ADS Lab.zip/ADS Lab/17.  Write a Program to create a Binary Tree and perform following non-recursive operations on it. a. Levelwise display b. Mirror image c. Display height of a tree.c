#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node* left;
    struct Node* right;
} Node;

typedef struct Queue {
    Node* arr[100];
    int front;
    int rear;
} Queue;

void initQueue(Queue* queue) {
    queue->front = -1;
    queue->rear = -1;
}

int isQueueEmpty(Queue* queue) {
    return queue->front == -1 || queue->front > queue->rear;
}

void enqueue(Queue* queue, Node* node) {
    if (queue->rear == 99) {
        printf("Queue overflow\n");
        return;
    }
    if (queue->front == -1) {
        queue->front = 0;
    }
    queue->arr[++queue->rear] = node;
}

Node* dequeue(Queue* queue) {
    if (isQueueEmpty(queue)) {
        printf("Queue underflow\n");
        return NULL;
    }
    return queue->arr[queue->front++];
}

Node* createNode(int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    return newNode;
}

Node* insert(Node* root, int data) {
    Node* newNode = createNode(data);
    if (root == NULL) {
        return newNode;
    }
    Queue queue;
    initQueue(&queue);
    enqueue(&queue, root);
    while (!isQueueEmpty(&queue)) {
        Node* current = dequeue(&queue);
        if (current->left == NULL) {
            current->left = newNode;
            break;
        } else {
            enqueue(&queue, current->left);
        }
        if (current->right == NULL) {
            current->right = newNode;
            break;
        } else {
            enqueue(&queue, current->right);
        }
    }
    return root;
}

void levelWiseDisplay(Node* root) {
    if (root == NULL) return;
    Queue queue;
    initQueue(&queue);
    enqueue(&queue, root);
    while (!isQueueEmpty(&queue)) {
        Node* current = dequeue(&queue);
        printf("%d ", current->data);
        if (current->left != NULL) {
            enqueue(&queue, current->left);
        }
        if (current->right != NULL) {
            enqueue(&queue, current->right);
        }
    }
    printf("\n");
}

void mirrorImage(Node* root) {
    if (root == NULL) return;
    Queue queue;
    initQueue(&queue);
    enqueue(&queue, root);
    while (!isQueueEmpty(&queue)) {
        Node* current = dequeue(&queue);
        Node* temp = current->left;
        current->left = current->right;
        current->right = temp;
        if (current->left != NULL) {
            enqueue(&queue, current->left);
        }
        if (current->right != NULL) {
            enqueue(&queue, current->right);
        }
    }
}

int getHeight(Node* root) {
    if (root == NULL) return 0;
    Queue queue;
    initQueue(&queue);
    enqueue(&queue, root);
    int height = 0;
    while (1) {
        int nodeCount = queue.rear - queue.front + 1;
        if (nodeCount == 0) return height;
        height++;
        while (nodeCount > 0) {
            Node* node = dequeue(&queue);
            if (node->left != NULL) enqueue(&queue, node->left);
            if (node->right != NULL) enqueue(&queue, node->right);
            nodeCount--;
        }
    }
}

int main() {
    Node* root = NULL;
    int choice, value;

    while (1) {
        printf("1. Insert\n");
        printf("2. Level-wise Display\n");
        printf("3. Mirror Image\n");
        printf("4. Display Height\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter value to insert: ");
                scanf("%d", &value);
                root = insert(root, value);
                break;
            case 2:
                printf("Level-wise Display: ");
                levelWiseDisplay(root);
                break;
            case 3:
                mirrorImage(root);
                printf("Tree mirrored successfully.\n");
                break;
            case 4:
                printf("Height of the Tree: %d\n", getHeight(root));
                break;
            case 5:
                exit(0);
            default:
                printf("Invalid choice\n");
                break;
        }
    }

    return 0;
}
