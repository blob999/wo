#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <limits.h>

#define MAX_VERTICES 10

typedef struct Node {
    int vertex;
    int weight;
    struct Node* next;
} Node;

typedef struct Graph {
    int numVertices;
    Node** adjLists;
} Graph;

Node* createNode(int v, int weight) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->vertex = v;
    newNode->weight = weight;
    newNode->next = NULL;
    return newNode;
}

Graph* createGraph(int vertices) {
    Graph* graph = (Graph*)malloc(sizeof(Graph));
    graph->numVertices = vertices;
    graph->adjLists = (Node**)malloc(vertices * sizeof(Node*));
    for (int i = 0; i < vertices; i++) {
        graph->adjLists[i] = NULL;
    }
    return graph;
}

void addEdge(Graph* graph, int src, int dest, int weight) {
    Node* newNode = createNode(dest, weight);
    newNode->next = graph->adjLists[src];
    graph->adjLists[src] = newNode;

    newNode = createNode(src, weight);
    newNode->next = graph->adjLists[dest];
    graph->adjLists[dest] = newNode;
}

void printAdjList(Graph* graph) {
    printf("Adjacency List:\n");
    for (int i = 0; i < graph->numVertices; i++) {
        printf("Vertex %d: ", i);
        Node* temp = graph->adjLists[i];
        while (temp) {
            printf("(%d, %d) ", temp->vertex, temp->weight);
            temp = temp->next;
        }
        printf("\n");
    }
}

void printMST(int parent[], Graph* graph) {
    printf("Minimum Spanning Tree Edges:\n");
    for (int i = 1; i < graph->numVertices; i++) {
        printf("Edge: %d - %d\n", parent[i], i);
    }
}

void primMST(Graph* graph) {
    int parent[MAX_VERTICES];
    int key[MAX_VERTICES];
    bool mstSet[MAX_VERTICES];

    for (int i = 0; i < graph->numVertices; i++) {
        key[i] = INT_MAX;
        mstSet[i] = false;
    }

    key[0] = 0;
    parent[0] = -1;

    for (int count = 0; count < graph->numVertices - 1; count++) {
        int minKey = INT_MAX, minIndex;

        for (int v = 0; v < graph->numVertices; v++) {
            if (mstSet[v] == false && key[v] < minKey) {
                minKey = key[v];
                minIndex = v;
            }
        }

        mstSet[minIndex] = true;
        Node* temp = graph->adjLists[minIndex];

        while (temp != NULL) {
            int v = temp->vertex;
            int weight = temp->weight;

            if (mstSet[v] == false && weight < key[v]) {
                parent[v] = minIndex;
                key[v] = weight;
            }
            temp = temp->next;
        }
    }
    printMST(parent, graph);
}

int main() {
    int vertices, numEdges, src, dest, weight;

    printf("Enter the number of vertices: ");
    scanf("%d", &vertices);
    Graph* graph = createGraph(vertices);

    printf("Enter the number of edges: ");
    scanf("%d", &numEdges);

    for (int i = 0; i < numEdges; i++) {
        printf("Enter source, destination, and weight for edge %d: ", i + 1);
        scanf("%d %d %d", &src, &dest, &weight);
        if (src >= 0 && src < vertices && dest >= 0 && dest < vertices)
            addEdge(graph, src, dest, weight);
        else {
            printf("Invalid vertices!\n");
            i--;
        }
    }

    printAdjList(graph);
    primMST(graph);
    return 0;
}
