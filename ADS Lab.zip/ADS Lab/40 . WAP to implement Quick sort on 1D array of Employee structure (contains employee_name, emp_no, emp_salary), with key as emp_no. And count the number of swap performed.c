#include<stdio.h>
#include<stdlib.h>

int size ;

struct emp {
    char na[50];
    int no;
    int sal;
} e[10];

void swap(struct emp *a, struct emp *b) {
    struct emp temp = *a;
    *a = *b;
    *b = temp;
}

int partition(struct emp emps[], int lower, int upper) {
    int pivot = upper;
    int i = lower - 1;

    for (int j = lower; j < upper; j++) {
        if (emps[j].no < emps[pivot].no) {
            i++;
            swap(&emps[i], &emps[j]);
        }
    }
    swap(&emps[i + 1], &emps[upper]);
    return (i + 1);
}

void quicksort(struct emp emps[], int lower, int upper) {
    if (lower < upper) {
        int partition_pos = partition(emps, lower, upper);
        quicksort(emps, lower, partition_pos - 1);
        quicksort(emps, partition_pos + 1, upper);
    }
}

void accept() {
    for (int i = 0; i < size; i++) {
        printf("\nEnter name: ");
        scanf("%s", e[i].na);
        printf("Enter emp no: ");
        scanf("%d", &e[i].no);
        printf("Enter salary: ");
        scanf("%d", &e[i].sal);
    }
}

void display() {
    for (int i = 0; i < size; i++) {
        printf("\nName: %s", e[i].na);
        printf("\nEmp no: %d", e[i].no);
        printf("\nSalary: %d", e[i].sal);
    }
}

int main() {
    printf("Enter the number of employees you want to add: ");
    scanf("%d", &size);
    accept();
    quicksort(e, 0, size - 1);
    display();
    return 0;
}
