#include <stdio.h>
#include <stdlib.h>
#define MAX_VERTICES 100

struct node {
    int vertex;
    int weight;
    struct node* next;
};

struct node* A[MAX_VERTICES];
int n;

int vertex(int dist[], int visited[]) {
    int min = 999, a;
    for(int i = 0; i < n; i++) {
        if(dist[i] < min && visited[i] == 0) {
            min = dist[i];
            a = i;
        }
    }
    return a;
}

void display(int dist[]) {
    printf("\nVertex \t Distance from Source:\n");
    for(int i = 0; i < n; i++)
        printf("%d\t%d\n", i, dist[i]);
}

void dj1(struct node* A[]) {
    int s;
    printf("\nEnter starting vertex: ");
    scanf("%d", &s);
    getchar(); // Consume newline character
    int dist[MAX_VERTICES], visited[MAX_VERTICES];
    for (int i = 0; i < n; i++) {
        dist[i] = 999;
        visited[i] = 0;
    }
    dist[s] = 0;
    for (int i = 0; i < n; i++) {
        int u = vertex(dist, visited);
        visited[u] = 1;
        struct node* current = A[u];
        while (current != NULL) {
            if (!visited[current->vertex] && dist[u] != 999 && dist[u] + current->weight < dist[current->vertex])
                dist[current->vertex] = dist[u] + current->weight;
            current = current->next;
        }
    }
    display(dist);
}

void list() {
    int u, v, w, num_edges;
    char ch;
    printf("Enter the number of vertices: ");
    scanf("%d", &n);
    getchar(); // Consume newline character
    printf("Enter the number of edges: ");
    scanf("%d", &num_edges);
    getchar(); // Consume newline character
    for (int i = 0; i < n; i++) {
        A[i] = NULL;
    }
    struct node* new;
    for (int i = 0; i < num_edges; i++) {
        printf("\nEnter edge %d/%d: ", i + 1, num_edges);
        scanf("%d %d", &u, &v);
        getchar(); // Consume newline character
        printf("\nEnter weight from edge %d to %d: ", u, v);
        scanf("%d", &w);
        getchar(); // Consume newline character
        new = (struct node*)malloc(sizeof(struct node));
        new->vertex = v;
        new->weight = w;
        new->next = A[u];
        A[u] = new;
        new = (struct node*)malloc(sizeof(struct node));
        new->vertex = u;
        new->weight = w;
        new->next = A[v];
        A[v] = new;
    }
}

int main() {
    int m;
    while (1) {
        printf("\n\n\t** MST Using Kruskal using Adjacency list and Matrix.");
        printf("\n1. Dijkstras Algorithm using matrix \n2. Dijkstras using Adjacency List \n3. Exit\n");
        printf("\nEnter which algorithm : ");
        scanf("%d", &m);
        getchar(); // Consume newline character
        switch (m) {
            case 1:
                list();
                dj1(A);
                break;
            case 2:
                exit(0);
            default:
                printf("\nEnter a valid option.");
        }
    }
    return 0;
}
