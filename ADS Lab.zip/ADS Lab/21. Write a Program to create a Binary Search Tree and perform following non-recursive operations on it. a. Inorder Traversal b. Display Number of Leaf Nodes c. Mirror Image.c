#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

// Definition of the Binary Tree Node
typedef struct Node {
    int data;
    struct Node* left;
    struct Node* right;
} Node;

// Stack structure for iterative tree traversal
typedef struct Stack {
    Node* data;
    struct Stack* next;
} Stack;

Stack* createStackNode(Node* data) {
    Stack* stackNode = (Stack*)malloc(sizeof(Stack));
    stackNode->data = data;
    stackNode->next = NULL;
    return stackNode;
}

void push(Stack** root, Node* data) {
    Stack* stackNode = createStackNode(data);
    stackNode->next = *root;
    *root = stackNode;
}

Node* pop(Stack** root) {
    if (*root == NULL) return NULL;
    Stack* temp = *root;
    *root = (*root)->next;
    Node* popped = temp->data;
    free(temp);
    return popped;
}

bool isStackEmpty(Stack* root) {
    return !root;
}

Node* peek(Stack* root) {
    if (isStackEmpty(root)) return NULL;
    return root->data;
}

// Function to create a new Binary Tree node
Node* createNode(int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    return newNode;
}

// Function to insert a node in the Binary Search Tree
// Node* insert(Node* root, int data) {
//     if (root == NULL) {
//         return createNode(data);
//     }
//     if (data < root->data) {
//         root->left = insert(root->left, data);
//     } else if (data > root->data) {
//         root->right = insert(root->right, data);
//     }
//     return root;
// }


// Non-recursive function to insert a node in the Binary Tree
Node* insert(Node* root, int data) {
    Node* newNode = createNode(data);
    if (root == NULL) {
        return newNode;
    }

    Node* current = root;
    Node* parent = NULL;

    while (current != NULL) {
        parent = current;
        if (data < current->data) {
            current = current->left;
        } else if (data > current->data) {
            current = current->right;
        } else {
            // Data already exists in the tree, no need to insert
            free(newNode);
            return root;
        }
    }

    if (data < parent->data) {
        parent->left = newNode;
    } else {
        parent->right = newNode;
    }

    return root;
}




// Non-recursive function to perform inorder traversal
void inorderTraversal(Node* root) {
    if (root == NULL) return;
    Stack *stack = NULL;
    Node *current = root;
    while (!isStackEmpty(stack) || current != NULL) {
        if (current != NULL) {
            push(&stack, current);
            current = current->left;
        } else {
            current = pop(&stack);
            printf("%d ", current->data);
            current = current->right;
        }
    }
    printf("\n");
}

// Non-recursive function to count leaf nodes
int countLeafNodes(Node* root) {
    if (root == NULL) return 0;
    int count = 0;
    Stack *stack = NULL;
    push(&stack, root);
    while (!isStackEmpty(stack)) {
        Node *current = pop(&stack);
        if (current->left == NULL && current->right == NULL) {
            count++;
        }
        if (current->right) push(&stack, current->right);
        if (current->left) push(&stack, current->left);
    }
    return count;
}

// Function to create a mirror image of the Binary Tree
void mirror(Node* root) {
    if (root == NULL) return;
    Stack *stack = NULL;
    push(&stack, root);
    while (!isStackEmpty(stack)) {
        Node *current = pop(&stack);
        Node *temp = current->left;
        current->left = current->right;
        current->right = temp;
        if (current->left) push(&stack, current->left);
        if (current->right) push(&stack, current->right);
    }
}

// Main function to demonstrate the operations
int main() {
    Node* root = NULL;
    int choice, value;

    while (1) {
        printf("\n1. Insert\n");
        printf("2. Inorder Traversal\n");
        printf("3. Display Number of Leaf Nodes\n");
        printf("4. Mirror Image\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter value to insert: ");
                scanf("%d", &value);
                root = insert(root, value);
                break;
            case 2:
                printf("Inorder Traversal: ");
                inorderTraversal(root);
                break;
            case 3:
                printf("Number of Leaf Nodes: %d\n", countLeafNodes(root));
                break;
            case 4:
                mirror(root);
                printf("Mirror image created.\n");
                break;
            case 5:
                exit(0);
            default:
                printf("Invalid choice\n");
                break;
        }
    }

    return 0;
}
