#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* left;
    struct Node* right;
    int isThreaded;
};

struct Node* createNode(int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    if (!newNode) {
        printf("Memory allocation error!\n");
        exit(1);
    }
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    newNode->isThreaded = 0;
    return newNode;
}

struct Node* insert(struct Node* root, int data) {
    if (root == NULL) {
        return createNode(data);
    }
    if (data < root->data) {
        root->left = insert(root->left, data);
    } else if (data > root->data) {
        root->right = insert(root->right, data);
    }
    return root;
}

struct Node* leftMost(struct Node* node) {
    if (node == NULL) {
        return NULL;
    }
    while (node->left != NULL) {
        node = node->left;
    }
    return node;
}

void createThreaded(struct Node* root, struct Node** prev) {
    if (root == NULL) {
        return;
    }
    createThreaded(root->left, prev);
    if (*prev != NULL && (*prev)->right == NULL) {
        (*prev)->right = root;
        (*prev)->isThreaded = 1;
    }
    *prev = root;
    createThreaded(root->right, prev);
}

void inorderTraversal(struct Node* root) {
    struct Node* current = leftMost(root);
    while (current != NULL) {
        printf("%d ", current->data);
        if (current->isThreaded) {
            current = current->right;
        } else {
            current = leftMost(current->right);
        }
    }
}

int main() {
    struct Node* root = NULL;
    root = insert(root, 6);
    insert(root, 3);
    insert(root, 8);
    insert(root, 1);
    insert(root, 5);
    insert(root, 7);
    insert(root, 9);

    struct Node* prev = NULL;
    createThreaded(root, &prev);

    printf("Inorder traversal: ");
    inorderTraversal(root);
    printf("\n");

    return 0;
}

