#include <stdio.h>
#include <stdlib.h>

// Structure for an employee record
typedef struct Employee {
    int emp_id;
    char name[50];
    struct Employee* left;
    struct Employee* right;
} Employee;

// Function to create a new employee record
Employee* createEmployee(int emp_id, const char* name) {
    Employee* newEmployee = (Employee*)malloc(sizeof(Employee));
    if (newEmployee == NULL) {
        printf("Memory allocation failed\n");
        exit(1);
    }
    newEmployee->emp_id = emp_id;
    strcpy(newEmployee->name, name);
    newEmployee->left = NULL;
    newEmployee->right = NULL;
    return newEmployee;
}

// Function to insert a new employee record into the BST
Employee* insertEmployee(Employee* root, int emp_id, const char* name) {
    if (root == NULL) {
        return createEmployee(emp_id, name);
    }
    if (emp_id < root->emp_id) {
        root->left = insertEmployee(root->left, emp_id, name);
    } else if (emp_id > root->emp_id) {
        root->right = insertEmployee(root->right, emp_id, name);
    }
    return root;
}

// Function to search for an employee record by emp_id
Employee* searchEmployee(Employee* root, int emp_id) {
    if (root == NULL || root->emp_id == emp_id) {
        return root;
    }
    if (emp_id < root->emp_id) {
        return searchEmployee(root->left, emp_id);
    } else {
        return searchEmployee(root->right, emp_id);
    }
}

// Function to display employee records in ascending order of emp_id (inorder traversal)
void displayEmployees(Employee* root) {
    if (root != NULL) {
        displayEmployees(root->left);
        printf("Emp ID: %d, Name: %s\n", root->emp_id, root->name);
        displayEmployees(root->right);
    }
}

int main() {
    Employee* root = NULL;

    // Insert employee records
    root = insertEmployee(root, 101, "John");
    root = insertEmployee(root, 105, "Alice");
    root = insertEmployee(root, 103, "Bob");
    root = insertEmployee(root, 109, "Emma");
    root = insertEmployee(root, 107, "Michael");

    // Display all employee records sorted by emp_id
    printf("Employee Records (Sorted by Emp ID):\n");
    displayEmployees(root);

    // Search for a particular employee record
    int search_emp_id = 103;
    Employee* found_employee = searchEmployee(root, search_emp_id);
    if (found_employee != NULL) {
        printf("\nEmployee Record Found for Emp ID %d: %s\n", search_emp_id, found_employee->name);
    } else {
        printf("\nEmployee Record not found for Emp ID %d\n", search_emp_id);
    }

    // Free memory allocated for the BST (not necessary in this program)

    return 0;
}
