#include <stdio.h>
#include <stdlib.h>

#define MAX_VERTICES 100

typedef struct {
    int vertices[MAX_VERTICES][MAX_VERTICES];
    int numVertices;
} Graph;

// Function to initialize the graph
void initializeGraph(Graph *graph) {
    graph->numVertices = 0;
    for (int i = 0; i < MAX_VERTICES; i++) {
        for (int j = 0; j < MAX_VERTICES; j++) {
            graph->vertices[i][j] = 0;
        }
    }
}

// Function to add an edge to the graph
void addEdge(Graph *graph, int from, int to) {
    graph->vertices[from][to] = 1;
    graph->vertices[to][from] = 1; // For undirected graph
    if (from > graph->numVertices) graph->numVertices = from;
    if (to > graph->numVertices) graph->numVertices = to;
}

// Function to perform BFS traversal
void BFS(Graph *graph, int startVertex) {
    int visited[MAX_VERTICES] = {0};
    int queue[MAX_VERTICES];
    int front = -1, rear = -1;

    // Enqueue the starting vertex
    queue[++rear] = startVertex;
    visited[startVertex] = 1;

    while (front < rear) {
        // Dequeue a vertex from the queue
        int currentVertex = queue[++front];
        printf("%d ", currentVertex);

        // Enqueue all adjacent vertices of the dequeued vertex that are not yet visited
        for (int i = 1; i <= graph->numVertices; i++) {
            if (graph->vertices[currentVertex][i] == 1 && visited[i] == 0) {
                queue[++rear] = i;
                visited[i] = 1;
            }
        }
    }
}

// Function to print the adjacency matrix with row and column names
// Function to print the adjacency matrix with row and column names
void printMatrix(Graph *graph) {
    printf("Adjacency Matrix:\n");
    printf("   |");
    for (int i = 1; i <= graph->numVertices; i++) {
        printf("%2d ", i);
    }
    printf("\n");
    printf("---+");
    for (int i = 1; i <= graph->numVertices; i++) {
        printf("---");
    }
    printf("\n");
    for (int i = 1; i <= graph->numVertices; i++) {
        printf("%2d |", i);
        for (int j = 1; j <= graph->numVertices; j++) {
            printf("%2d ", graph->vertices[i][j]);
        }
        printf("\n");
    }
}


int main() {
    Graph graph;
    initializeGraph(&graph);

    int numEdges, from, to;

    // Input the number of edges
    printf("Enter the number of edges: ");
    scanf("%d", &numEdges);

    // Input the edges
    printf("Enter the edges (from to): \n");
    for (int i = 0; i < numEdges; i++) {
        scanf("%d %d", &from, &to);
        addEdge(&graph, from, to);
    }

    // Print the adjacency matrix with row and column names
    printMatrix(&graph);

    // Input the starting vertex for BFS
    int startVertex;
    printf("\nEnter the starting vertex for BFS: ");
    scanf("%d", &startVertex);

    printf("BFS Traversal starting from vertex %d: ", startVertex);
    BFS(&graph, startVertex);
    printf("\n");

    return 0;
}
