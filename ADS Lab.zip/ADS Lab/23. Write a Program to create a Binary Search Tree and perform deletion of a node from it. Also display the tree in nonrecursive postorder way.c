#include <stdio.h>
#include <stdlib.h>

// Definition of the Binary Tree Node
typedef struct Node {
    int data;
    struct Node* left;
    struct Node* right;
} Node;

// Stack structure for iterative tree traversal
typedef struct Stack {
    Node* data;
    struct Stack* next;
} Stack;

Stack* createStackNode(Node* data) {
    Stack* stackNode = (Stack*)malloc(sizeof(Stack));
    stackNode->data = data;
    stackNode->next = NULL;
    return stackNode;
}

void push(Stack** root, Node* data) {
    Stack* stackNode = createStackNode(data);
    stackNode->next = *root;
    *root = stackNode;
}

Node* pop(Stack** root) {
    if (*root == NULL) return NULL;
    Stack* temp = *root;
    *root = (*root)->next;
    Node* popped = temp->data;
    free(temp);
    return popped;
}

int isStackEmpty(Stack* root) {
    return !root;
}

// Function to create a new Binary Tree node
Node* createNode(int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    return newNode;
}

// Function to insert a node in the Binary Search Tree
// Node* insert(Node* root, int data) {
//     if (root == NULL) {
//         return createNode(data);
//     }
//     if (data < root->data) {
//         root->left = insert(root->left, data);
//     } else if (data > root->data) {
//         root->right = insert(root->right, data);
//     }
//     return root;
// }


// Non-recursive function to insert a node in the Binary Tree
Node* insert(Node* root, int data) {
    Node* newNode = createNode(data);
    if (root == NULL) {
        return newNode;
    }

    Node* current = root;
    Node* parent = NULL;

    while (current != NULL) {
        parent = current;
        if (data < current->data) {
            current = current->left;
        } else if (data > current->data) {
            current = current->right;
        } else {
            // Data already exists in the tree, no need to insert
            free(newNode);
            return root;
        }
    }

    if (data < parent->data) {
        parent->left = newNode;
    } else {
        parent->right = newNode;
    }

    return root;
}




// Function to find the minimum value node in a tree
Node* minValueNode(Node* node) {
    Node* current = node;
    while (current && current->left != NULL) {
        current = current->left;
    }
    return current;
}

// Function to delete a node from the Binary Search Tree
Node* deleteNode(Node* root, int key) {
    if (root == NULL) return root;
    if (key < root->data) {
        root->left = deleteNode(root->left, key);
    } else if (key > root->data) {
        root->right = deleteNode(root->right, key);
    } else {
        if (root->left == NULL) {
            Node* temp = root->right;
            free(root);
            return temp;
        } else if (root->right == NULL) {
            Node* temp = root->left;
            free(root);
            return temp;
        }
        Node* temp = minValueNode(root->right);
        root->data = temp->data;
        root->right = deleteNode(root->right, temp->data);
    }
    return root;
}

// Function to display the tree in non-recursive postorder traversal
void postorderTraversal(Node* root) {
    if (root == NULL) return;
    Stack* stack1 = NULL;
    Stack* stack2 = NULL;
    push(&stack1, root);
    while (!isStackEmpty(stack1)) {
        Node* current = pop(&stack1);
        push(&stack2, current);
        if (current->left) push(&stack1, current->left);
        if (current->right) push(&stack1, current->right);
    }
    while (!isStackEmpty(stack2)) {
        Node* current = pop(&stack2);
        printf("%d ", current->data);
    }
    printf("\n");
}

// Main function to demonstrate the operations
int main() {
    Node* root = NULL;
    int choice, value;

    while (1) {
        printf("\n1. Insert\n");
        printf("2. Delete\n");
        printf("3. Display Non-recursive Postorder Traversal\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter value to insert: ");
                scanf("%d", &value);
                root = insert(root, value);
                break;
            case 2:
                printf("Enter value to delete: ");
                scanf("%d", &value);
                root = deleteNode(root, value);
                break;
            case 3:
                printf("Non-recursive Postorder Traversal: ");
                postorderTraversal(root);
                break;
            case 4:
                exit(0);
            default:
                printf("Invalid choice\n");
                break;
        }
    }

    return 0;
}
