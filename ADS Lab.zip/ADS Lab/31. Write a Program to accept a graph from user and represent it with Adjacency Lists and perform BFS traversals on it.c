#include <stdio.h>
#include <stdlib.h>

#define MAX_VERTICES 100

// Structure for representing a node in adjacency list
typedef struct AdjListNode {
    int dest;
    struct AdjListNode* next;
} AdjListNode;

// Structure for representing adjacency list
typedef struct {
    AdjListNode* head;
} AdjList;

// Structure for representing the graph
typedef struct {
    int numVertices;
    AdjList* array;
} Graph;

// Function to create a new adjacency list node
AdjListNode* newAdjListNode(int dest) {
    AdjListNode* newNode = (AdjListNode*)malloc(sizeof(AdjListNode));
    newNode->dest = dest;
    newNode->next = NULL;
    return newNode;
}

// Function to create a graph with given number of vertices
Graph* createGraph(int numVertices) {
    Graph* graph = (Graph*)malloc(sizeof(Graph));
    graph->numVertices = numVertices;

    // Create an array of adjacency lists. Size of the array will be numVertices.
    graph->array = (AdjList*)malloc(numVertices * sizeof(AdjList));

    // Initialize each adjacency list as empty by making head as NULL
    for (int i = 0; i < numVertices; ++i)
        graph->array[i].head = NULL;

    return graph;
}

// Function to add an edge to an undirected graph
void addEdge(Graph* graph, int src, int dest) {
    // Add an edge from src to dest. A new node is added to the adjacency list of src.
    AdjListNode* newNode = newAdjListNode(dest);
    newNode->next = graph->array[src].head;
    graph->array[src].head = newNode;

    // Since graph is undirected, add an edge from dest to src also
    newNode = newAdjListNode(src);
    newNode->next = graph->array[dest].head;
    graph->array[dest].head = newNode;
}

// Function to print the adjacency lists
void printAdjLists(Graph* graph) {
    printf("Adjacency Lists:\n");
    for (int v = 0; v < graph->numVertices; ++v) {
        printf("Vertex %d: ", v);
        AdjListNode* temp = graph->array[v].head;
        while (temp) {
            printf("%d ", temp->dest);
            temp = temp->next;
        }
        printf("\n");
    }
}

// Function to perform Breadth First Search (BFS) traversal
void BFS(Graph* graph, int startVertex) {
    // Create a boolean array to mark visited vertices
    int* visited = (int*)calloc(graph->numVertices, sizeof(int));

    // Create a queue for BFS
    int* queue = (int*)malloc(graph->numVertices * sizeof(int));
    int front = 0, rear = 0;

    // Mark the current node as visited and enqueue it
    visited[startVertex] = 1;
    queue[rear++] = startVertex;

    // Traverse the graph
    printf("BFS Traversal starting from vertex %d: ", startVertex);
    while (front < rear) {
        // Dequeue a vertex from the queue and print it
        int vertex = queue[front++];
        printf("%d ", vertex);

        // Get all adjacent vertices of the dequeued vertex
        AdjListNode* adjNode = graph->array[vertex].head;
        while (adjNode) {
            int adjVertex = adjNode->dest;
            // If adjacent vertex is not visited, mark it as visited and enqueue it
            if (!visited[adjVertex]) {
                visited[adjVertex] = 1;
                queue[rear++] = adjVertex;
            }
            adjNode = adjNode->next;
        }
    }
    printf("\n");

    // Free dynamically allocated memory
    free(visited);
    free(queue);
}

int main() {
    int numVertices, numEdges, from, to;

    // Input the number of vertices and edges
    printf("Enter the number of vertices and edges: ");
    scanf("%d %d", &numVertices, &numEdges);

    // Create a graph with given number of vertices
    Graph* graph = createGraph(numVertices);

    // Input the edges
    printf("Enter the edges (from to): \n");
    for (int i = 0; i < numEdges; ++i) {
        scanf("%d %d", &from, &to);
        addEdge(graph, from, to);
    }

    // Print the adjacency lists
    printAdjLists(graph);

    // Input the starting vertex for BFS traversal
    int startVertex;
    printf("Enter the starting vertex for BFS traversal: ");
    scanf("%d", &startVertex);

    // Perform BFS traversal starting from the given vertex
    BFS(graph, startVertex);

    // Free dynamically allocated memory
    free(graph);

    return 0;
}
