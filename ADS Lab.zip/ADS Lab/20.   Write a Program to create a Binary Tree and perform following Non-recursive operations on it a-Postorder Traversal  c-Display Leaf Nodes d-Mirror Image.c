#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

// Definition of the Binary Tree Node
typedef struct Node {
    int data;
    struct Node* left;
    struct Node* right;
} Node;

// Queue structure for level-order insertion
typedef struct Queue {
    Node* data;
    struct Queue* next;
} Queue;

Queue* createQueueNode(Node* data) {
    Queue* queueNode = (Queue*)malloc(sizeof(Queue));
    queueNode->data = data;
    queueNode->next = NULL;
    return queueNode;
}

void enqueue(Queue** rear, Node* data) {
    Queue* queueNode = createQueueNode(data);
    if (*rear == NULL) {
        *rear = queueNode;
    } else {
        Queue* temp = *rear;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = queueNode;
    }
}

Node* dequeue(Queue** front) {
    if (*front == NULL) return NULL;
    Queue* temp = *front;
    *front = (*front)->next;
    Node* dequeued = temp->data;
    free(temp);
    return dequeued;
}

bool isQueueEmpty(Queue* front) {
    return !front;
}

// Function to create a new Binary Tree node
Node* createNode(int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    return newNode;
}

// Non-recursive function to insert a node in the Binary Tree (level-order)
Node* insert(Node* root, int data) {
    Node* newNode = createNode(data);
    if (root == NULL) {
        return newNode;
    }

    Queue* queue = NULL;
    enqueue(&queue, root);

    while (!isQueueEmpty(queue)) {
        Node* current = dequeue(&queue);

        if (current->left == NULL) {
            current->left = newNode;
            break;
        } else {
            enqueue(&queue, current->left);
        }

        if (current->right == NULL) {
            current->right = newNode;
            break;
        } else {
            enqueue(&queue, current->right);
        }
    }

    return root;
}

// Stack structure for iterative tree traversal
typedef struct Stack {
    Node* data;
    struct Stack* next;
} Stack;

Stack* createStackNode(Node* data) {
    Stack* stackNode = (Stack*)malloc(sizeof(Stack));
    stackNode->data = data;
    stackNode->next = NULL;
    return stackNode;
}

void push(Stack** root, Node* data) {
    Stack* stackNode = createStackNode(data);
    stackNode->next = *root;
    *root = stackNode;
}

Node* pop(Stack** root) {
    if (*root == NULL) return NULL;
    Stack* temp = *root;
    *root = (*root)->next;
    Node* popped = temp->data;
    free(temp);
    return popped;
}

bool isStackEmpty(Stack* root) {
    return !root;
}

Node* peek(Stack* root) {
    if (isStackEmpty(root)) return NULL;
    return root->data;
}

// Non-recursive function to perform postorder traversal
void postorderTraversal(Node* root) {
    if (root == NULL) return;
    Stack *stack = NULL;
    Node *current = root, *lastVisited = NULL;
    while (!isStackEmpty(stack) || current != NULL) {
        if (current != NULL) {
            push(&stack, current);
            current = current->left;
        } else {
            Node *peekNode = peek(stack);
            if (peekNode->right != NULL && lastVisited != peekNode->right) {
                current = peekNode->right;
            } else {
                printf("%d ", peekNode->data);
                lastVisited = pop(&stack);
            }
        }
    }
    printf("\n");
}

// Non-recursive function to display leaf nodes
void displayLeafNodes(Node* root) {
    if (root == NULL) return;
    Stack *stack = NULL;
    push(&stack, root);
    while (!isStackEmpty(stack)) {
        Node *current = pop(&stack);
        if (current->left == NULL && current->right == NULL) {
            printf("%d ", current->data);
        }
        if (current->right) push(&stack, current->right);
        if (current->left) push(&stack, current->left);
    }
    printf("\n");
}

// Function to create a mirror image of the Binary Tree
void mirror(Node* root) {
    if (root == NULL) return;
    Stack *stack = NULL;
    push(&stack, root);
    while (!isStackEmpty(stack)) {
        Node *current = pop(&stack);
        Node *temp = current->left;
        current->left = current->right;
        current->right = temp;
        if (current->left) push(&stack, current->left);
        if (current->right) push(&stack, current->right);
    }
}

// Main function to demonstrate the operations
int main() {
    Node* root = NULL;
    int choice, value;

    while (1) {
        printf("\n1. Insert\n");
        printf("2. Postorder Traversal\n");
        printf("3. Display Leaf Nodes\n");
        printf("4. Mirror Image\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter value to insert: ");
                scanf("%d", &value);
                root = insert(root, value);
                break;
            case 2:
                printf("Postorder Traversal: ");
                postorderTraversal(root);
                break;
            case 3:
                printf("Leaf Nodes: ");
                displayLeafNodes(root);
                break;
            case 4:
                mirror(root);
                printf("Mirror image created.\n");
                break;
            case 5:
                exit(0);
            default:
                printf("Invalid choice\n");
                break;
        }
    }

    return 0;
}
