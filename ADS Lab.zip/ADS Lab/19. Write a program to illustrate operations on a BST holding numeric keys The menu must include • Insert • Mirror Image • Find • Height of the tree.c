#include <stdio.h>
#include <stdlib.h>

// Definition of the BST node
typedef struct Node {
    int data;
    struct Node* left;
    struct Node* right;
} Node;

// Function to create a new BST node
Node* createNode(int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    return newNode;
}

// Function to insert a new node into the BST
Node* insert(Node* root, int data) {
    if (root == NULL) {
        return createNode(data);
    }
    if (data < root->data) {
        root->left = insert(root->left, data);
    } else if (data > root->data) {
        root->right = insert(root->right, data);
    }
    return root;
}

// Function to find a node in the BST
Node* find(Node* root, int data) {
    while (root != NULL) {
        if (data < root->data) {
            root = root->left;
        } else if (data > root->data) {
            root = root->right;
        } else {
            return root;
        }
    }
    return NULL;
}

// Function to create a mirror image of the BST
Node* mirror(Node* root) {
    if (root == NULL) {
        return NULL;
    }
    Node* temp = root->left;
    root->left = root->right;
    root->right = temp;
    mirror(root->left);
    mirror(root->right);
    return root;
}

// Function to calculate the height of the BST
int height(Node* root) {
    if (root == NULL) {
        return 0;
    }
    int leftHeight = height(root->left);
    int rightHeight = height(root->right);
    return (leftHeight > rightHeight ? leftHeight : rightHeight) + 1;
}

// Function to perform in-order traversal of the BST (for display)
void inorder(Node* root) {
    if (root != NULL) {
        inorder(root->left);
        printf("%d ", root->data);
        inorder(root->right);
    }
}

int main() {
    Node* root = NULL;
    int choice, value;

    while (1) {
        printf("\n1. Insert\n");
        printf("2. Mirror Image\n");
        printf("3. Find\n");
        printf("4. Height of the tree\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter value to insert: ");
                scanf("%d", &value);
                root = insert(root, value);
                printf("In-order traversal of the BST: ");
                inorder(root);
                printf("\n");
                break;
            case 2:
                root = mirror(root);
                printf("Mirror image created. In-order traversal of the BST: ");
                inorder(root);
                printf("\n");
                break;
            case 3:
                printf("Enter value to find: ");
                scanf("%d", &value);
                Node* foundNode = find(root, value);
                if (foundNode != NULL) {
                    printf("Node %d found in the BST.\n", value);
                } else {
                    printf("Node %d not found in the BST.\n", value);
                }
                break;
            case 4:
                printf("Height of the tree: %d\n", height(root));
                break;
            case 5:
                exit(0);
            default:
                printf("Invalid choice\n");
                break;
        }
    }

    return 0;
}
